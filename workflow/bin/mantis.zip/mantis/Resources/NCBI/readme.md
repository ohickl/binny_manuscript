These files were downloaded on 2021-06-24 11:02:46 from:
https://ftp.ncbi.nlm.nih.gov/pub/taxonomy/new_taxdump/new_taxdump.tar.gz
ftp://ftp.ncbi.nih.gov/entrez/misc/data/gc.prt
They are used to traceback organism lineage for taxonomically resolved annotations and to translate CDS