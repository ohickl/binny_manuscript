Custom references will go here

Please use one folder per source otherwise it won't be recognized.

If using a HMM, please use hmmpress on the hmm within each folder.
If using sequences, use Diamond to create a Diamond database.

example1.tar.gz contains an example custom hmm source.

You can also use the function ```merge_hmm_folder``` to merge a target folder with hmms. This function will merge all hmms into one global hmm and then press it.
