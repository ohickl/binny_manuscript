Default hmms will go here
